//Back End 10 - Salsabila Adrian
const { json } = require('express')
let express = require('express')
let app = express()
let port = 3000
let m = require('./models/index')

app.use(express.json())

app.listen(port, () => {
    console.log('Example app listen to port 3000')
})

app.get('/provience', (req, res) => {
    let findprov = m.Provience.findAll().then(function (r) {
        if (r.length < 1) {
            res.json({ message: "Provience not available" })
        }

        res.json(r)
    })
})

app.post('/provience', (req, res) => {
    let createprov = m.Provience.create(req.body)
    if (!createprov) {
        console.error('Error Create Provience!')
    }
    res.json(req.body)
})

app.get('/city', (req, res) => {
    let findcity = m.City.findAll().then(function (r) {
        if (r.length < 1) {
            res.json({ message: "City not available" })
        }

        res.json(r)
    })
})

app.post('/city', (req, res) => {
    let createcity = m.City.create(req.body)
    if (!createcity) {
        console.error('Error Create City!')
    }
    res.json(req.body)
})

